<script setup>
import Carrtido from '@/components/Carrito.vue'
</script>
<template><Carrtido/></template>
<style></style>