<script setup>
import Acerca from '@/components/Acerca.vue';
</script>
<template>

<Acerca/>

</template>