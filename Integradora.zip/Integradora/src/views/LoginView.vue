<template>
 <LoginC/>
</template>
<script setup>
import LoginC  from '@/components/LoginC.vue';
</script>