<template>
  <v-app>
    <default-view />
  </v-app>
</template>

<script setup>
  import DefaultView from './View.vue'
</script>
